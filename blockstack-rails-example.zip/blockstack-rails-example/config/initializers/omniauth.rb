Rails.application.config.middleware.use OmniAuth::Builder do
    provider :blockstack
end

#This adds the OmniAuth middleware to your project, and tells OmniAuth to use the Blockstack provider. After a user signs in with OmniAuth, you need to specify a callback method for Blockstack to handle the rest of the sign in flow.
#The callback method is typically where you grab the authentication information from the third party, save some data, and sign the user in to your application by saving information in cookies.